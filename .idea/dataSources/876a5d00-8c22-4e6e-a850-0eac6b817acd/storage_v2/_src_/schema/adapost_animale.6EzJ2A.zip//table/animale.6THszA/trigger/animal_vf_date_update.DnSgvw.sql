create definer = root@localhost trigger animal_vf_date_update
    before update
    on animale
    for each row
    IF( NEW.`data_inregistrare` > CURRENT_DATE()) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'INVALID UPDATE';
    END IF;

