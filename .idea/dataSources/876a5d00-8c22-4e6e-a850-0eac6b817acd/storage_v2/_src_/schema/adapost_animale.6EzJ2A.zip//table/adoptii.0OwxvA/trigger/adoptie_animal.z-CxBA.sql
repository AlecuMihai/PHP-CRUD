create definer = root@localhost trigger adoptie_animal
    after insert
    on adoptii
    for each row
BEGIN
    UPDATE `ocupare_custi`
    SET data_final = NEW.data_adoptie
    WHERE id_animal = NEW.id_animal AND
        data_final IS NULL;
END;

