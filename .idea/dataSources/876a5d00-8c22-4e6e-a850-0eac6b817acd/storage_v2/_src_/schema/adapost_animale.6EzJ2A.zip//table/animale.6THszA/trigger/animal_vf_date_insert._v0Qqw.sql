create definer = root@localhost trigger animal_vf_date_insert
    before insert
    on animale
    for each row
    IF( NEW.`data_inregistrare` > CURRENT_DATE()) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'INVALID INPUT DATA';
    END IF;

