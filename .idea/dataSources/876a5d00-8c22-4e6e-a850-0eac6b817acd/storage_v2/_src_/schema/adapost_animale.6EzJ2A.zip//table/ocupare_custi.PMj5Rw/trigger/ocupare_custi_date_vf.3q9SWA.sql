create definer = root@localhost trigger ocupare_custi_date_vf
    before insert
    on ocupare_custi
    for each row
BEGIN
    IF EXISTS (SELECT 1 FROM `ocupare_custi`
               WHERE `id_animal` = NEW.`id_animal`
                 AND
                   data_final IS NULL) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'INVALID INSERTION';
    END IF;
END;

